int ParseNetAddr(const char *address, unsigned char *octlets);
int ParseConfig(const char *path, char *ip_address, char *subnet_mask, char *gateway);
