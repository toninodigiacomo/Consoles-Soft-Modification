int ParseNetAddr(const char *address, unsigned char *octlets);
